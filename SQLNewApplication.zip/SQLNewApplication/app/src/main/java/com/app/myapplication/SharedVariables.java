package com.app.myapplication;

public class SharedVariables {
	
	public static String ip = "192.168.0.103";
	public static String classs = "net.sourceforge.jtds.jdbc.Driver";
	public static String db = "h";
	//db = "Payroll";
	public static String un = "hitesh";
	public static String password = "789";

}
